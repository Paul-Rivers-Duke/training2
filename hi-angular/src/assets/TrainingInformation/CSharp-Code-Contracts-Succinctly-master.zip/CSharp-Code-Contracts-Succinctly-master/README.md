# C# Code Contracts Succinctly
This is the companion repo for [*C# Code Contracts Succinctly*](https://www.syncfusion.com/ebooks/csharpcontracts) by Dirk Strauss. Published by Syncfusion.

[![cover](https://github.com/SyncfusionSuccinctlyE-Books/CSharp-Code-Contracts-Succinctly/blob/master/cover.png)](https://www.syncfusion.com/ebooks/csharpcontracts)

## Looking for more _Succinctly_ titles?

Check out the entire library of more than 130 _Succinctly_ e-books at [https://www.syncfusion.com/ebooks](https://www.syncfusion.com/ebooks).

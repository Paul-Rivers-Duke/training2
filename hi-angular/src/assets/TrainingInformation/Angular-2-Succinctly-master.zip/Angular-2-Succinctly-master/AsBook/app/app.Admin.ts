/*
    Admin component
*/
import { Component } from '@angular/core';
  @Component({
    template: '<h3>Admin</h3>'
   })
export class AppAdmin {}
/**
 * Joe Booth:  Angular 2 Succinctly
 */
export interface Team{
    id:number,
    name: string,
    type: string     // Co-ed, Over-30, Open  
}
 
# Angular 2 Succinctly

This is the companion repo for [*Angular 2 Succinctly*](https://www.syncfusion.com/ebooks/Angular2_Succinctly) by Joseph D. Booth. Published by Syncfusion.

[![cover](https://github.com/SyncfusionSuccinctlyE-Books/Angular-2-Succinctly/blob/master/cover.png)](https://www.syncfusion.com/ebooks/Angular2_Succinctly)

## Looking for more _Succinctly_ titles?

Check out the entire library of more than 130 _Succinctly_ e-books at [https://www.syncfusion.com/ebooks](https://www.syncfusion.com/ebooks).

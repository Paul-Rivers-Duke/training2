/*
    Scoring component
*/
import { Component } from '@angular/core';
  @Component({
    template: '<h3>Scoring</h3>'
   })
export class AppScoring { }

import { Component } from '@angular/core';
  @Component({
    selector: 'main-app',
    templateUrl: './app/Views/MainMenu.html'
   })
export class AppComponent { name='Blaire'; }
